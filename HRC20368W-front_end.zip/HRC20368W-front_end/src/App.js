import "./App.css";
import MyGrid from "./components/MyGrid";
// import Header from "./components/Header";
function App() {
  return (
    <>
      <MyGrid />
    </>
  );
}
export default App;
